import React from "react";
import { useUser } from "../../hooks/UserContext";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import UploadImg from "./UploadImg";
import "./MyPage.css";

export default function MyPage() {
  const { user } = useUser();

  if (!user) return <p>로그인이 필요합니다.</p>;

  return (
    <div className="mypage-container">
      <div className="sidebar">
        <Link to="/mypage/message">쪽지함</Link>
        <Link to="/mypage/nickname">닉네임 변경</Link>
        <Link to="/mypage/password">비밀번호 변경</Link>
      </div>

      <div className="mypage-main">
        <h2>마이페이지</h2>
        <p>여기에 오른쪽 콘텐츠가 표시됩니다.</p>

        <div className="profile-card">
          <UploadImg />
      
          <div className="profile-info">
            <h3>{user.name}</h3>
            <p>아이디 : {user.loginId}</p>
            <p>등급   : 👑관리자</p>
            <p>
              깃허브 주소   :
              <a
                href="https://github.com/HB-KWon"
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "#ffffff" }} // ✅ 흰색으로 지정
              >
                https://github.com/HB-KWon
              </a>
            </p>

          </div>
        </div>
      </div>
    </div>
  );
}
