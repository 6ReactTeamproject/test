// AppRouter.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import TravelIntro from "./components/Travel/TravelIntro";
import CreateTravelIntro from "./components/Travel/CreateTravelIntro";
import DetailTravel from "./components/Travel/DetailTravel";
import TeamIntro from "./components/TeamIntro";
import PostBoard from "./pages/Board.jsx";
import Login from "./components/Login/Login.jsx";
import Home from "./Home.jsx"; // 새로 추가한 컴포넌트

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/intro" element={<TravelIntro />} />
      <Route path="/intro/new" element={<CreateTravelIntro />} />
      <Route path="/intro/:id" element={<DetailTravel />} />
      <Route path="/team" element={<TeamIntro />} />
      <Route path="/board" element={<PostBoard />} />
    </Routes>
  );
}
