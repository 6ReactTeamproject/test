import { useEffect, useState } from "react";

const API_URL = "http://localhost:3001/members"

function TeamIntro() {
  const [members, setMembers] = useState([]);
  const [memberName, setMemberName] = useState("");
  const [memberRole, setMemberRole] = useState("");
  const [memberContent, setMemberContent] = useState("");
  const [memberPicture, setMemberPicture] = useState("");
  const [magnifyMember, setMagnifyMember] = useState(null);
  
  const handleMemberClick = (memberId) => {
    fetch(`${API_URL}/${memberId}`, {
      method: "GET"
    })
    .then(res => res.json())
    .then(data => setMagnifyMember(data))
  }

  const fetchMembers = () => {
    fetch(API_URL)
    .then(res => res.json())
    .then(data => setMembers(data));
  }

  const handleSubmit = () => {
    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name:memberName, role:memberRole, introduction:memberContent, profileImage:memberPicture }),
    }).then(() => {
      alert("멤버가 생성되었습니다.");
      setMemberName("");
      setMemberRole("");
      setMemberContent("");
      setMemberPicture("");
      fetchMembers();
    });
  };

function EditMember({ memberId }) {
  const handleUpdate = () => {
    fetch(`${API_URL}/${memberId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name:memberName, role:memberRole, introduction:memberContent, profileImage:memberPicture }),
    }).then(() => {
      alert("멤버가 수정되었습니다.");
      setMemberName("");
      setMemberRole("");
      setMemberContent("");
      setMemberPicture("");
      fetchMembers();
    });
  };
  return (
    <button onClick={handleUpdate}
    >edit</button>
  )
};
  
function DeleteMember({ memberId }) {
  const handleDelete = () => {  
    fetch(`${API_URL}/${memberId}`, {
      method: "DELETE",
    }).then(() => {
      alert("멤버가 삭제되었습니다.")
      fetchMembers();
    });
  }
  return (
    <button onClick={handleDelete}
    >delete</button>
  )
};

  useEffect(() => {
    fetch(API_URL)
      .then(res => res.json())
      .then(data => setMembers(data));
    fetchMembers();
  }, []);

  return (
    <div>
      <h2>조원 소개1231231313213</h2>
      <div>
        <input 
          value={memberName} onChange={(e) => setMemberName(e.target.value)}
          placeholder="이름"
        />
        <br/>
        <input 
          value={memberRole} onChange={(e) => setMemberRole(e.target.value)}
          placeholder="역할"
          />
        <br/>
        <textarea
          value={memberContent} onChange={(e) => setMemberContent(e.target.value)}
          placeholder="내용"
        />
        <br/>

        <input type="file" accept="image/*" onChange={(e) => {
          const file = e.target.files[0];
          if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
              setMemberPicture(reader.result)
            };
            reader.readAsDataURL(file);
          }
        }}
        ></input>
        <br />
        <button onClick={memberName !="" && memberRole !=""
          ? handleSubmit
          : () => alert("이름과 역할은 반드시 입력해야 합니다.")
          }
        >추가</button>
      </div>
      <ul>
        {members.map(member => (
          <li key={member.id} onClick = {() => handleMemberClick(member.id)}>
            <strong>{member.name}</strong> - {member.role}  
            <p>{member.introduction}</p>
            <img src={member.profileImage} alt={member.name} width={100} />
            <EditMember memberId={member.id} />
            <DeleteMember memberId={member.id} />
          </li>
        ))}
      </ul>
      {magnifyMember && (
        <div >
          <h3>{magnifyMember.name} 상세 보기</h3>
          <p>{magnifyMember.role}</p>
          <p>{magnifyMember.introduction}</p>
          <img src={magnifyMember.profileImage} alt={magnifyMember.name} width={300} />
        </div>
      )}
    </div>
  );
}

export default TeamIntro;