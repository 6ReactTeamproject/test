// MemberList.jsx
import EditMember from "./EditMember";
import DeleteMember from "./DeleteMember";

function MemberList({ members, onMemberClick, fetchMembers, setMemberName, setMemberRole, setMemberContent, setMemberPicture }) {
  return (
    <ul>
      {members.map(member => (
        <li key={member.id} onClick={() => onMemberClick(member.id)}>
          <strong>{member.name}</strong> - {member.role}
          <p>{member.introduction}</p>
          <img src={member.profileImage} alt={member.name} width={100} />
          <EditMember 
            memberId={member.id} 
            memberName={member.name} 
            memberRole={member.role} 
            memberContent={member.introduction} 
            memberPicture={member.profileImage} 
            fetchMembers={fetchMembers} 
            setMemberName={setMemberName} 
            setMemberRole={setMemberRole} 
            setMemberContent={setMemberContent} 
            setMemberPicture={setMemberPicture} 
          />
          <DeleteMember memberId={member.id} fetchMembers={fetchMembers} />
        </li>
      ))}
    </ul>
  );
}

export default MemberList;