// DeleteMember.jsx
function DeleteMember({ memberId, fetchMembers }) {
  const API_URL = "http://localhost:3001/members";

  const handleDelete = () => {
    fetch(`${API_URL}/${memberId}`, {
      method: "DELETE",
    }).then(() => {
      alert("멤버가 삭제되었습니다.");
      fetchMembers();
    });
  };

  return <button onClick={handleDelete}>delete</button>;
}

export default DeleteMember;
