// MemberDetail.jsx
function MemberDetail({ member }) {
  return (
    <div>
      <h3>{member.name} 상세 보기</h3>
      <p>{member.role}</p>
      <p>{member.introduction}</p>
      <img src={member.profileImage} alt={member.name} width={300} />
    </div>
  );
}

export default MemberDetail;
