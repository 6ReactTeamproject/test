// MemberForm.jsx
function MemberForm({
  memberName, setMemberName,
  memberRole, setMemberRole,
  memberContent, setMemberContent,
  memberPicture, setMemberPicture,
  onSubmit
}) {
  return (
    <div>
      <input value={memberName} onChange={(e) => setMemberName(e.target.value)} placeholder="이름" /><br />
      <input value={memberRole} onChange={(e) => setMemberRole(e.target.value)} placeholder="역할" /><br />
      <textarea value={memberContent} onChange={(e) => setMemberContent(e.target.value)} placeholder="내용" /><br />
      <input type="file" accept="image/*" onChange={(e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onloadend = () => setMemberPicture(reader.result);
          reader.readAsDataURL(file);
        }
      }} /><br />
      <button onClick={memberName && memberRole ? onSubmit : () => alert("이름과 역할은 반드시 입력해야 합니다.")}>추가</button>
    </div>
  );
}

export default MemberForm;
