// EditMember.jsx
function EditMember({ memberId, memberName, memberRole, memberContent, memberPicture, fetchMembers, setMemberName, setMemberRole, setMemberContent, setMemberPicture }) {
  const API_URL = "http://localhost:3001/members";

  const handleUpdate = () => {
    fetch(`${API_URL}/${memberId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: memberName, role: memberRole, introduction: memberContent, profileImage: memberPicture })
    }).then(() => {
      alert("멤버가 수정되었습니다.");
      setMemberName("");
      setMemberRole("");
      setMemberContent("");
      setMemberPicture("");
      fetchMembers();
    });
  };

  return <button onClick={handleUpdate}>edit</button>;
}

export default EditMember;