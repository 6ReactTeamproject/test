// Main.jsx
import { useNavigate } from "react-router-dom";

export default function Main() {
  const navigate = useNavigate();

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>메인 화면</h1>
      <button onClick={() => navigate("/login")}>로그인</button>
      <br /><br />
      <button onClick={() => navigate("/intro")}>여행 소개</button>
      <br /><br />
      <button onClick={() => navigate("/team")}>멤버 소개</button>
      <br /><br />
      <button onClick={() => navigate("/board")}>게시판</button>
    </div>
  );
}
